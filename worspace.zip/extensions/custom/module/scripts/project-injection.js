/*

Copyright 2010, Google Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
copyright notice, this list of conditions and the following disclaimer
in the documentation and/or other materials provided with the
distribution.
    * Neither the name of Google Inc. nor the names of its
contributors may be used to endorse or promote products derived from
this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,           
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY           
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

// This file is added to the /project page

var BuscaCEP = 
{
	init: function()
	{
		// Add item to Column Menu
		DataTableColumnHeaderUI.extendMenu(
	    function(column, columnHeaderUI, menu) 
	    {
	    	if(column.name.toUpperCase() == "CEP")
		      	MenuSystem.insertAfter(menu, ["core/reconcile"], [
	        	{
		            id: "core/busca-cep",
	    	        label: "CEP -> Addr",
	        	    click: function() 
	            	{
	            		var jsonCol = Math.random(0, 9999).toString();
	            		
	            		$("[bind='progressDiv']").show();
	            		$("[bind='processPanelDiv']").show();
	            		$("#notification-container").show();
	            		$("[bind='progressDescription']").html("Convertendo CEPs...");	            		
	            		$("[bind='undoDiv']").hide();

	                	$.post(BuscaCEP.rootUrl()+"/command/core/add-column-by-fetching-urls",
	                	{
	                		baseColumnName: column.name,
	                		urlExpression: "grel:if(and(isNonBlank(value), value.length() >= 8), 'http://cep.correiocontrol.com.br/'+replace(replace(value, \"-\", \"\"), \".\", \"\")+'.json', null)",
	                		newColumnName: jsonCol,
	                		columnInsertIndex: "2",
	                		delay: "250",
	                		project: BuscaCEP.getProjectId(),
	                		onError:"set-to-blank"	                		
	                	}, function(data)
	                	{
	                		console.log(data);
	      					window.setTimeout(function()
		            		{
		            			BuscaCEP.checkProcesses(jsonCol)
	            			}, 1000);
	                	});
	            	}
	        	},
	      	]);
	    });
	},
	checkProcesses: function(colName, r)
	{
		if(r == null) r = false;

		$.getJSON(BuscaCEP.rootUrl() + "/command/core/get-processes",
		{
			project: BuscaCEP.getProjectId()
		}, function(data)
		{
			if(!data.processes.length)
			{
				if(!r)
					BuscaCEP.json2addr(colName);
				else
				{
					$.post(BuscaCEP.rootUrl() + "/command/core/remove-column",
					{
						columnName: colName,
						project: BuscaCEP.getProjectId()
					}, function(data)
					{
						document.location.reload();
					});
				}
			}
			else
			{
				$("[bind='progressDescription']").html("Convertendo CEPs... ("+data.processes[0].progress+"%)");	
				window.setTimeout(function()
				{
					BuscaCEP.checkProcesses(colName, r)
				}, 1000);
			}
		});
	},
	json2addr: function(colName)
	{
		$.post(BuscaCEP.rootUrl()+"/command/core/add-column",
    	{
    		baseColumnName: colName,
    		expression: 'grel:value.parseJson().get("logradouro")+", "+value.parseJson().get("bairro")+", "+value.parseJson().get("localidade")+"-"+toUppercase(value.parseJson().get("uf"))',
    		newColumnName: 'Endereço',
    		columnInsertIndex:'3',
    		onError:'set-to-blank',
    		project: BuscaCEP.getProjectId()

    	}, function(d)
    	{
    		console.log(d);
    		BuscaCEP.checkProcesses(colName, true);
    	});
	},
	getProjectId: function()
	{
		return document.location.toString().split("=").pop();
	},
	rootUrl: function()
	{
		return document.location.protocol + "//" + document.location.host;
	}
};

var TitleCase = 
{
	init: function()
	{
		// Add item to Column Menu
		DataTableColumnHeaderUI.extendMenu(
	    function(column, columnHeaderUI, menu) 
	    {
	    	MenuSystem.insertAfter(menu, ["core/reconcile"], [
	        {
	            id: "core/title-br",
    	        label: "Titlecase (pt-br)",
        	    click: function() 
            	{
						$("[bind='progressDiv']").show();
	            		$("[bind='processPanelDiv']").show();
	            		$("#notification-container").show();
	            		$("[bind='progressDescription']").html("Transformando strings...");	            		
	            		$("[bind='undoDiv']").hide();

            		$.post(TitleCase.rootUrl()+"/command/core/text-transform",
                	{
                		columnName: column.name,
						expression:'grel:replace(replace(replace(replace(replace(value.toTitlecase(), " Do ", " do "), " Da ", " da "), " Dos ", " dos "), " Das ", " das "), " De ", " de ")',
						onError:'keep-original',
						repeat:'false',
						repeatCount:'10',
						project: TitleCase.getProjectId(),
                	}, function(data)
                	{
                		console.log(data);
      					document.location.reload();
                	});
            	}
	        }]);
	    });
	},
	getProjectId: function()
	{
		return document.location.toString().split("=").pop();
	},
	rootUrl: function()
	{
		return document.location.protocol + "//" + document.location.host;
	}
};

window.onload = function()
{
	BuscaCEP.init();
	console.log("BuscaCEP initialized...");

	TitleCase.init();
	console.log("Titlecase initialized...");
}