import json
import urllib

value = "13083-755"
url = 'http://cep.correiocontrol.com.br/%s.json'
query = urllib.urlopen(url % value.replace("-", "")).read()

try:
    data = json.loads(query)
    return data["logradouro"]+", "+data["bairro"]+", "+data["localidade"]+"-"+data["uf"]
except ValueError:
    return null